import java.io.*;
import java.util.Scanner;

public class notesManager {
    static final String basePath = "Java notes manager/JavaNotes/"; //rename with your path

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Java Notes Manager ---");
            System.out.println("1. Create JavaFile1.txt");
            System.out.println("2. Display JavaFile1.txt");
            System.out.println("3. Create & update JavaFile2.txt");
            System.out.println("4. Analyze JavaFile1.txt");
            System.out.println("5. Search for 'polymorphism' in JavaFile1.txt");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> createJavaFile1(sc);
                case 2 -> displayFile(basePath + "JavaFile1.txt");
                case 3 -> createAndUpdateJavaFile2();
                case 4 -> analyzeJavaFile1();
                case 5 -> searchPolymorphism();
                case 6 -> System.out.println("Exiting. Bye!");
                default -> System.out.println("Invalid choice.");
            }
        } while (choice != 6);
    }

    static void createJavaFile1(Scanner sc) {
        File folder = new File(basePath);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        try (FileWriter writer = new FileWriter(basePath + "JavaFile1.txt")) {
            System.out.println("Enter 4 lines of text for JavaFile1:");
            for (int i = 0; i < 4; i++) {
                String line = sc.nextLine();
                writer.write(line + "\n");
            }
            System.out.println("JavaFile1.txt saved in H:/Java project/JavaNotes/");
        } catch (IOException e) {
            System.out.println("Error writing file.");
        }
    }

    static void displayFile(String filename) {
        System.out.println("\n--- File Content ---");
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file.");
        }
    }

    static void createAndUpdateJavaFile2() {
        File folder = new File(basePath);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        try (FileWriter fw = new FileWriter(basePath + "JavaFile2.txt")) {
            fw.write("This is the first line in this JavaFile2.txt file.\n");
        } catch (IOException e) {
            System.out.println("Error writing to JavaFile2.txt");
            return;
        }

        System.out.println("\n--- Original Content of JavaFile2.txt ---");
        displayFile(basePath + "JavaFile2.txt");

        try (
            BufferedReader reader = new BufferedReader(new FileReader(basePath + "JavaFile1.txt"));
            FileWriter fwAppend = new FileWriter(basePath + "JavaFile2.txt", true)
        ) {
            String line;
            while ((line = reader.readLine()) != null) {
                fwAppend.write(line + "\n");
            }
        } catch (IOException e) {
            System.out.println("Error copying content.");
        }

        System.out.println("\n--- Updated Content of JavaFile2.txt ---");
        displayFile(basePath + "JavaFile2.txt");
    }

    static void analyzeJavaFile1() {
        int charCount = 0;
        int wordCount = 0;
        int lineCount = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(basePath + "JavaFile1.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lineCount++;
                charCount += line.length();
                wordCount += line.split("\\s+").length;
            }
            System.out.println("Analysis of JavaFile1.txt:");
            System.out.println("Total Lines: " + lineCount);
            System.out.println("Total Words: " + wordCount);
            System.out.println("Total Characters: " + charCount);
        } catch (IOException e) {
            System.out.println("Error reading file.");
        }
    }

    static void searchPolymorphism() {
        int lineNumber = 0;
        int totalCount = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(basePath + "JavaFile1.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                if (line.contains("polymorphism")) {
                    System.out.println("'polymorphism' found on line: " + lineNumber);
                    for (String word : line.split("\\s+")) {
                        if (word.equals("polymorphism")) {
                            totalCount++;
                        }
                    }
                }
            }
            System.out.println("Total occurrences of 'polymorphism': " + totalCount);
        } catch (IOException e) {
            System.out.println("Error reading file.");
        }
    }
}
